/**
 * Upload Handler JavaScript File
 * Handles file uploads, text submissions, and API communication
 */

// Configuration
const CONFIG = {
    // Correct API endpoint (replace with actual backend URL)
    apiEndpoint: 'http://127.0.0.1:8000/predict',
    
    // File upload constraints
    maxFileSize: 5, // MB
    allowedImageTypes: ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'],
    
    // Text constraints
    maxTextLength: 10000,
    minTextLength: 50
};

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initUploadForms();
    initToggleButtons();
    initTextCounter();
    initFileUpload();
});

/**
 * Initialize upload form handlers
 */
function initUploadForms() {
    const textForm = document.getElementById('textForm');
    const imageForm = document.getElementById('imageForm');
    
    // Handle text form submission
    if (textForm) {
        textForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const textContent = document.getElementById('textContent').value.trim();
            
            // Validate text input
            if (!validateTextInput(textContent)) return;
            
            // Submit to API
            await submitToAPI('text', textContent);
        });
    }
    
    // Handle image form submission
    if (imageForm) {
        imageForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const fileInput = document.getElementById('imageFile');
            const file = fileInput.files[0];
            
            if (!file) {
                window.appUtils.showNotification('Please select an image file', 'error');
                return;
            }
            
            if (!validateImageFile(file)) return;
            
            try {
                const base64Data = await window.appUtils.fileToBase64(file);
                await submitToAPI('image', base64Data);
            } catch (error) {
                console.error('Error converting file:', error);
                window.appUtils.showNotification('Failed to process image file', 'error');
            }
        });
    }
}

/**
 * Initialize toggle buttons for switching between text and image modes
 */
function initToggleButtons() {
    const toggleButtons = document.querySelectorAll('.toggle-btn');
    const textForm = document.getElementById('textForm');
    const imageForm = document.getElementById('imageForm');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const mode = this.getAttribute('data-mode');
            
            toggleButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            if (mode === 'text') {
                textForm.classList.add('active');
                imageForm.classList.remove('active');
            } else {
                textForm.classList.remove('active');
                imageForm.classList.add('active');
            }
            
            clearResults();
        });
    });
}

/**
 * Initialize character counter for text input
 */
function initTextCounter() {
    const textContent = document.getElementById('textContent');
    const charCount = document.getElementById('charCount');
    
    if (textContent && charCount) {
        textContent.addEventListener('input', function() {
            const count = this.value.length;
            charCount.textContent = count;
            charCount.style.color = count > CONFIG.maxTextLength
                ? '#ef4444'
                : count >= CONFIG.minTextLength
                    ? '#10b981'
                    : '#94a3b8';
        });
    }
}

/**
 * Initialize file upload drag and drop functionality
 */
function initFileUpload() {
    const fileUploadArea = document.getElementById('fileUploadArea');
    const fileInput = document.getElementById('imageFile');
    const imagePreview = document.getElementById('imagePreview');
    
    if (!fileUploadArea || !fileInput) return;
    
    fileUploadArea.addEventListener('click', () => fileInput.click());
    
    fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (file) handleFileSelect(file);
    });
    
    fileUploadArea.addEventListener('dragover', e => {
        e.preventDefault();
        fileUploadArea.style.borderColor = '#3b82f6';
        fileUploadArea.style.background = '#f1f5f9';
    });
    
    fileUploadArea.addEventListener('dragleave', e => {
        e.preventDefault();
        fileUploadArea.style.borderColor = '#e2e8f0';
        fileUploadArea.style.background = '';
    });
    
    fileUploadArea.addEventListener('drop', e => {
        e.preventDefault();
        fileUploadArea.style.borderColor = '#e2e8f0';
        fileUploadArea.style.background = '';
        
        const file = e.dataTransfer.files[0];
        if (file) {
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            fileInput.files = dataTransfer.files;
            handleFileSelect(file);
        }
    });
    
    function handleFileSelect(file) {
        if (!validateImageFile(file)) {
            fileInput.value = '';
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.innerHTML = `
                <img src="${e.target.result}" alt="Preview">
                <p style="margin-top: 0.5rem; color: #64748b; font-size: 0.875rem;">
                    ${file.name} (${window.appUtils.formatFileSize(file.size)})
                </p>
            `;
            imagePreview.classList.add('active');
        };
        reader.readAsDataURL(file);
        
        window.appUtils.showNotification('Image loaded successfully', 'success');
    }
}

/**
 * Validate text input
 */
function validateTextInput(text) {
    if (text.length < CONFIG.minTextLength) {
        window.appUtils.showNotification(`Text must be at least ${CONFIG.minTextLength} characters`, 'error');
        return false;
    }
    if (text.length > CONFIG.maxTextLength) {
        window.appUtils.showNotification(`Text must not exceed ${CONFIG.maxTextLength} characters`, 'error');
        return false;
    }
    return true;
}

/**
 * Validate image file
 */
function validateImageFile(file) {
    if (!window.appUtils.validateFileType(file, CONFIG.allowedImageTypes)) {
        window.appUtils.showNotification('Invalid file type. Please upload JPG, PNG, or GIF images only', 'error');
        return false;
    }
    if (!window.appUtils.validateFileSize(file, CONFIG.maxFileSize)) {
        window.appUtils.showNotification(`File size must not exceed ${CONFIG.maxFileSize}MB`, 'error');
        return false;
    }
    return true;
}

/**
 * Submit content to API for analysis
 */
async function submitToAPI(type, content) {
    const loadingOverlay = document.getElementById('loadingOverlay');
    try {
        loadingOverlay.classList.add('active');
        
        // Prepare request body
        let requestData;
        if (type === 'text') {
            requestData = { text: content }; // <-- Must match backend Pydantic model
        } else {
            requestData = { image: content };
        }
        
        console.log('Submitting to API:', requestData);
        
        const response = await fetch(CONFIG.apiEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });
        
        if (!response.ok) throw new Error(`API returned status ${response.status}`);
        
        const result = await response.json();
        displayResults(result);
        window.appUtils.showNotification('Analysis completed successfully', 'success');
    } catch (error) {
        console.error('API Error:', error);
        window.appUtils.showNotification('Using mock data (API endpoint not available)', 'warning');
        displayMockResults(type, content);
    } finally {
        loadingOverlay.classList.remove('active');
    }
}

/**
 * Display analysis results
 */
function displayResults(data) {
    const resultsContent = document.getElementById('resultsContent');
    const isFake = data.result.toLowerCase() === 'fake';
    const confidence = Math.round(data.confidence * 100);
    
    resultsContent.innerHTML = `
        <div class="result-badge ${isFake ? 'fake' : 'real'}">
            <i class="fas fa-${isFake ? 'exclamation-triangle' : 'check-circle'}"></i>
            ${data.result.toUpperCase()}
        </div>
        <div class="confidence-bar">
            <div class="confidence-label">
                <span>Confidence Score</span>
                <span>${confidence}%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${confidence}%"></div>
            </div>
        </div>
        <div class="result-explanation">
            <h4><i class="fas fa-info-circle"></i> Analysis Explanation</h4>
            <p>${data.explanation || 'The content has been analyzed using advanced AI algorithms to determine its authenticity.'}</p>
        </div>
        <div style="margin-top: 1.5rem; padding: 1rem; background: var(--bg-tertiary); border-radius: 0.75rem; font-size: 0.875rem; color: var(--text-secondary);">
            <p><strong>Note:</strong> This analysis is based on AI algorithms and should be used as a guide. Always verify important information with multiple credible sources.</p>
        </div>
    `;
    
    if (window.historyModule && data.content) {
        window.historyModule.addToHistory({
            type: data.type || 'text',
            content: data.content,
            result: data.result,
            confidence: data.confidence,
            explanation: data.explanation
        });
    }
    
    const resultsCard = document.querySelector('.results-card');
    if (resultsCard) resultsCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/**
 * Display mock results for demonstration
 */
function displayMockResults(type, content) {
    const isFake = Math.random() > 0.5;
    const confidence = isFake ? 0.65 + Math.random() * 0.25 : 0.70 + Math.random() * 0.25;
    
    const explanations = {
        fake: [
            'Content shows characteristics commonly associated with misinformation.',
            'Multiple red flags: unverified claims, misleading headlines.',
            'Linguistic patterns suggest potential manipulation.'
        ],
        real: [
            'Content appears legitimate based on source credibility.',
            'Analysis indicates authentic journalism characteristics.',
            'Cross-referencing confirms information is trustworthy.'
        ]
    };
    
    displayResults({
        type,
        content,
        result: isFake ? 'Fake' : 'Real',
        confidence,
        explanation: isFake ? explanations.fake[Math.floor(Math.random() * explanations.fake.length)] : explanations.real[Math.floor(Math.random() * explanations.real.length)]
    });
}

/**
 * Clear results display
 */
function clearResults() {
    const resultsContent = document.getElementById('resultsContent');
    resultsContent.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <p>No analysis yet. Upload content to get started.</p>
        </div>
    `;
}

/**
 * Reset upload forms
 */
function resetForms() {
    document.getElementById('textForm').reset();
    document.getElementById('imageForm').reset();
    document.getElementById('charCount').textContent = '0';
    
    const imagePreview = document.getElementById('imagePreview');
    imagePreview.innerHTML = '';
    imagePreview.classList.remove('active');
    
    clearResults();
}

// Export functions
window.uploadHandler = { submitToAPI, displayResults, resetForms, clearResults };
